﻿using System;
using HugsLib;

namespace Milk
{
	public class MilkBase : ModBase
	{
		public override string ModIdentifier
		{
			get
			{
				return "MilkableColonists";
			}
		}
	}
}
