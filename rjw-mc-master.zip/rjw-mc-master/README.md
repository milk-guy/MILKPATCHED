And why would you read me?

Mod git:  
https://gitgud.io/Ed86/rjw-mc

Discord:  
https://discord.gg/CXwHhv8

LoversLab:  
https://www.loverslab.com/topic/139736-milkable-colonists-updated-for-11/

Requirements:  
Harmony  
Hugslib  
Rimjobworld (https://gitgud.io/Ed86/rjw)  

Additional features to RimJobWorld:  
	- milk for humanlikes  
	- natural/pregnancy milk production  
	- drugs related milk production   
	- beasts size increase due to milking  
